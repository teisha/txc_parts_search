const gulp = require('gulp');
const newer = require('gulp-newer');
const uglify = require('gulp-uglify');
const imageMin = require('gulp-imagemin');
const ejs = require("gulp-ejs");
const cssnano = require("gulp-cssnano");
const zip = require("gulp-zip");
const terser = require("gulp-terser");
const del = require('del');

const devBuild = (process.env.NODE_ENV !== 'production');
/*
 -- TOP LEVEL FUNCTIONS --
 gulp.task - Define tasks
 gulp.src - Point to files to use
 gulp.dest - points to folder to output
 gulp.watch - watch files and folders for changes
*/

var paths = {

  tmp: 'tmp',
  tmpIndex: 'tmp/index.html',
  tmpCSS: 'tmp/**/*.css',
  tmpJS: 'tmp/**/*.js',
  dist: 'dist',
  distIndex: 'dist/index.html',
  distCSS: 'dist/**/*.css',
  distJS: 'dist/**/*.js',
  srcJS : ['public/js/*.js',
  			'controllers/**/*.js',
  			'middleware/**/*.js',
  			'routes/**/*.js',
  			'services/**/*.js',
  			'util/**/*.js'],
  srcCSS: 'public/css/*.css',
  srcImages: 'public/images/*',
  srcEjs : 'views/**/*.ejs',
  build: 'build/**',
  buildImages: 'build/public/images/**/*',
  buildEjs: 'build/views/**',
  buildCSS: 'build/public/css',
  buildJS : 'build/**/*.js'
};

function clean() {
	return gulp.del(['build/**', '!build/public/images', '!build'], {force:true});
}

function deployDev() {
	return gulp.series(message, clean, 
		gulp.parallel(copyCss, copyImages),
		copyEjs, copyScripts);
}

function deployProd() {
	return gulp.series(zipProduction);
}

function zipProduction() {
	const zipFile = 'txc_parts_search-' + getFormattedDate() + '.zip';
    return gulp.src(paths.build)
        .pipe(zip(zipFile))
        .pipe(gulp.dest('deploy/*'));
}

function getFormattedDate(date) {
	let date = new Date();
	return date.getDate() + date.getMonth()+1 + date.getFullYear() ;
}

gulp.task('message', function() {
  return Promise.resolve(console.log('Begin Deploy') );
});

//must be called after images
function copyEjs() {
	const out = paths.buildEjs;
	return gulp.src(paths.srcEjs)
		.pipe(ejs())
		.pipe(gulp.dest(out));
}

function copyImages() {
	const out = paths.buildImages;
	return gulp.src(paths.srcImages)
		.pipe(newer(out))
		.pipe(imageMin())
		.pipe(gulp.dest(out));
}

function copyCss() {
	const out = paths.buildCSS;
	return gulp.src(paths.srcCSS)
		.pipe(newer(out))
		.pipe(cssnano())
		.pipe(gulp.dest(out));
}

function copyScripts() {
	return gulp.src(paths.srcJS)
		.pipe(terser())
		.pipe(gulp.dest(paths.buildJS))
}

exports.deploydev = deployDev;
exports.scripts = copyScripts;
exports.css = copyCss;
exports.images = copyImages;
exports.ejs = copyEjs;